Github link to ipython notebook:
https://github.com/vidit09/unsupNN/blob/master/MiniProject_Kohonen_clustering_Original.ipynb